#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <locale.h>

#define MAX_MATCHES 10000

typedef struct {
    int hafta;
    int gun;
    int saat;
    int dakika;
    int takimA;
    int takimB;
} Mac;

void macYazdir(Mac mac) {
    printf("Hafta %d - Gun %d - %02d:%02d - %d. Takim ve %d. Takim\n", mac.hafta, mac.gun, mac.saat, mac.dakika, mac.takimA, mac.takimB);
}

int main() {
    setlocale(LC_ALL, "TURKISH");
    int takimSayisi;
    int hafta = 1;
    int toplamMacSayisi;
    int saat, dakika, gun, toplamHaftaSayisi;
    int oynananMaclar = 0;

    Mac rovanslar[MAX_MATCHES];
    int rovansSayaci = 0;

    srand(time(0));

    printf("Kac takim var?: ");
    scanf("%d", &takimSayisi);

    if (takimSayisi < 2) {
        printf("Gecersiz takim sayisi! En az 2 takim olmalidir.\n");
        return 1;
    }

    toplamMacSayisi = takimSayisi * (takimSayisi - 1);
    toplamHaftaSayisi = (takimSayisi - 1) * 2;
    int oynananMaclarTablosu[takimSayisi][takimSayisi];
    for (int i = 0; i < takimSayisi; i++) {
        for (int j = 0; j < takimSayisi; j++) {
            oynananMaclarTablosu[i][j] = 0;  // Başlangıçta tüm maçlar oynanmadı (0)
        }
    }

    while (oynananMaclar < toplamMacSayisi) {
        int haftaIcindeOynayanlar[100] = {0};  // Takımların bu hafta oynayıp oynamadığını kontrol et
        int gunlukMacSayisi[7] = {0};  // Her gün kaç maç yapıldığını say

        printf("\n===== Hafta %d =====\n", hafta);

        for (int i = 0; i < takimSayisi; i++) {
            for (int j = i + 1; j < takimSayisi; j++) {
                // Eğer maç yapılmadıysa ve iki takım bu hafta oynamadıysa
                if (!oynananMaclarTablosu[i][j] && !haftaIcindeOynayanlar[i] && !haftaIcindeOynayanlar[j]) {

                    gun = 1 + rand() % 7;  // 1 ile 7 arasında rastgele bir gün seç
                    saat = rand() % 23;  // Saat 00:00 ile 22:00 arasında rastgele bir saat seç
                    int dakikaSecenekleri[] = {0, 15, 30, 45};  // Dakika seçenekleri 0, 15, 30, 45
                    dakika = dakikaSecenekleri[rand() % 4];

                    // Maç en geç 22:15'te başlayabilir
                    if (saat == 22 && dakika > 15) {
                        dakika = 15;
                    }

                    // Eğer o gün 8 maçtan az oynanmışsa
                    if (gunlukMacSayisi[gun - 1] < 8) {
                        Mac mac = {hafta, gun, saat, dakika, i + 1, j + 1};
                        macYazdir(mac);
                        oynananMaclar++;
                        gunlukMacSayisi[gun - 1]++;

                        haftaIcindeOynayanlar[i] = 1;  // Takım i bu hafta oynadı
                        haftaIcindeOynayanlar[j] = 1;  // Takım j bu hafta oynadı
                        oynananMaclarTablosu[i][j] = 1;  // Takım i ve j arasında maç yapıldı

                        // Rövanş maçını rastgele bir gelecekteki haftaya planla
                        int rovansHaftasi = hafta + 1 + rand() % (toplamHaftaSayisi - hafta);
                        gun = 1 + rand() % 7;
                        saat = rand() % 23;
                        dakika = dakikaSecenekleri[rand() % 4];
                        if(saat==22 && dakika>15){
                            dakika=15;
                        }

                        // Rövanş maçını planla, eğer daha önce yapılmadıysa
                        if (!oynananMaclarTablosu[j][i]) {
                            Mac rovansMaci = {rovansHaftasi, gun, saat, dakika, j + 1, i + 1};
                            rovanslar[rovansSayaci++] = rovansMaci;
                            oynananMaclar++;
                            oynananMaclarTablosu[j][i] = 1;  // Rövanş maçı da oynanmış sayılır
                        }
                    }
                }
            }
        }

        hafta++;
    }

    printf("\n===== Rovans Maclari =====\n");
    for (int i = 0; i < rovansSayaci; i++) {
        macYazdir(rovanslar[i]);
    }

    printf("\nToplam %d mac planlandi.\n", oynananMaclar);

    return 0;
}
